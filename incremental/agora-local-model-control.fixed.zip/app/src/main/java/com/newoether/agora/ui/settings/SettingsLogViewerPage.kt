package com.newoether.agora.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.newoether.agora.R
import com.newoether.agora.util.DebugLog
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsLogViewerPage(onBack: () -> Unit) {
    var logs by remember { mutableStateOf(DebugLog.history()) }
    val listState = rememberLazyListState()
    val context = LocalContext.current

    // Poll the in-memory buffer once per second and keep the view pinned to the newest entry.
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            logs = DebugLog.history()
            if (logs.isNotEmpty()) {
                runCatching { listState.scrollToItem(logs.lastIndex) }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.log_viewer_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Agora logs", DebugLog.asText()))
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.log_viewer_copy))
                    }
                    IconButton(onClick = {
                        DebugLog.clear()
                        logs = emptyList()
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.log_viewer_clear))
                    }
                },
            )
        },
    ) { padding ->
        if (logs.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(R.string.log_viewer_empty),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 24.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                items(logs) { entry ->
                    Text(
                        text = "${DebugLog.formatTime(entry.time)} ${entry.level}/${entry.tag}: ${entry.msg}",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        modifier = Modifier.padding(vertical = 2.dp),
                    )
                }
            }
        }
    }
}
