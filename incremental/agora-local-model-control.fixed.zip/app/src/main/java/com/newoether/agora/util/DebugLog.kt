package com.newoether.agora.util

import android.content.Context
import android.util.Log
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue

object DebugLog {
    @Volatile
    var forceEnabled = false
    @Volatile
    private var enabled = true

    /** In-memory ring buffer so logs can be surfaced inside the app (Settings ▸ 日志查看). */
    private val queue = ConcurrentLinkedQueue<Entry>()
    private const val MAX_ENTRIES = 3000

    data class Entry(
        val time: Long,
        val level: Char,
        val tag: String,
        val msg: String,
    )

    fun init(context: Context) {
        enabled = forceEnabled || (context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
    }

    private val active: Boolean get() = forceEnabled || enabled

    private fun record(level: Char, tag: String, msg: String) {
        if (!active) return
        synchronized(queue) {
            queue.add(Entry(System.currentTimeMillis(), level, tag, msg))
            while (queue.size > MAX_ENTRIES) queue.poll()
        }
    }

    /** Snapshot of buffered log entries, oldest first. */
    fun history(): List<Entry> = synchronized(queue) { ArrayList(queue) }

    /** Whole buffer as a single newline-separated string (for copy / share). */
    fun asText(): String {
        val sb = StringBuilder()
        for (e in history()) {
            sb.append(formatTime(e.time)).append(' ').append(e.level).append('/')
                .append(e.tag).append(": ").append(e.msg).append('\n')
        }
        return sb.toString()
    }

    fun clear() {
        synchronized(queue) { queue.clear() }
    }

    fun formatTime(ms: Long): String {
        val sdf = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)
        return sdf.format(Date(ms))
    }

    fun d(tag: String, msg: String) {
        if (active) {
            Log.d(tag, msg)
            record('D', tag, msg)
        }
    }

    fun d(tag: String, msg: String, tr: Throwable) {
        if (active) {
            val full = "$msg ${safeThrowableSummary(tr)}"
            Log.d(tag, full)
            record('D', tag, full)
        }
    }

    fun e(tag: String, msg: String) {
        if (active) {
            Log.e(tag, msg)
            record('E', tag, msg)
        }
    }

    fun e(tag: String, msg: String, tr: Throwable) {
        if (active) {
            val full = "$msg ${safeThrowableSummary(tr)}"
            Log.e(tag, full)
            record('E', tag, full)
        }
    }

    fun w(tag: String, msg: String) {
        if (active) {
            Log.w(tag, msg)
            record('W', tag, msg)
        }
    }

    fun w(tag: String, msg: String, tr: Throwable) {
        if (active) {
            val full = "$msg ${safeThrowableSummary(tr)}"
            Log.w(tag, full)
            record('W', tag, full)
        }
    }

    /**
     * Throwable messages and cause chains frequently contain request URLs, response excerpts,
     * local paths, or user content. Keep the exception type and application stack locations for
     * diagnostics without forwarding those uncontrolled strings to Logcat.
     */
    internal fun safeThrowableSummary(tr: Throwable): String = buildString {
        append("exception=")
        append(tr.javaClass.name)
        tr.stackTrace
            .asSequence()
            .take(MAX_SAFE_STACK_FRAMES)
            .forEach { frame ->
                append("\n\tat ")
                append(frame)
            }
    }

    private const val MAX_SAFE_STACK_FRAMES = 24
}
