# 增量包部署说明（Incremental Package）

本目录用于存放 **增量包（.zip）**，配合仓库根目录的 `.github/workflows/apply-incremental.yml`
工作流实现 **unzip-and-overwrite** 式自动部署。

## 如何使用

1. 将增量包（例如 `agora-local-model-control.zip`）放入本 `incremental/` 目录。
2. 提交并推送到 `master` 分支：
   ```bash
   git add incremental/agora-local-model-control.zip
   git commit -m "chore: add incremental package for local model control"
   git push origin master
   ```
3. GitHub Actions 会自动：
   - 解压增量包（包内为「仓库相对路径」）；
   - 覆盖式写入对应文件；
   - 以含 `[skip ci]` 的提交信息推送，避免工作流自触发死循环。

也可以到仓库 **Actions ▸ Apply Incremental Package ▸ Run workflow** 手动运行，
并通过 `package` 输入参数指定包路径（默认 `incremental/agora-local-model-control.zip`）。

## 增量包内容约定

- 包内每个条目都是**相对于仓库根目录**的路径，例如：
  `app/src/main/java/com/newoether/agora/api/local/LocalProvider.kt`
- 解压即覆盖，无需手动合并；如需保留历史，请使用 Pull Request 流程。
- 新增文件直接包含完整文件；修改文件包含**修改后的完整文件**（不是 diff）。
